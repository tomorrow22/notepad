import com.itheima.domain.Message;
import com.itheima.ui.AddJFrame;
import com.itheima.ui.AppJFrame;
import com.itheima.ui.UpdateJFrame;

import java.io.IOException;
import java.util.ArrayList;

public class App {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        //启动！
        new AppJFrame();
    }
}
