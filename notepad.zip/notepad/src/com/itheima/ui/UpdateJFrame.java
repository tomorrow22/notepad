package com.itheima.ui;

import com.itheima.domain.Message;
import com.itheima.util.CommentUtil;

import javax.swing.*;
import javax.swing.text.JTextComponent;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class UpdateJFrame extends JFrame implements KeyListener, ActionListener {
    Container pane = this.getContentPane();
    //信息对象
    private Message m;
    //标题输入框
    JTextField titleField = new JTextField();
    //内容输入框
    JTextArea textArea = new JTextArea();
    //装有标题输入框和内容输入框的集合
    ArrayList<JTextComponent> list = new ArrayList<>();
    JButton updateButton = new JButton("修改");
    JButton cancelButton = new JButton("取消");
    //记录要修改的条目索引
    int index = 0;
    //临时集合记录传过来的信息对象
    ArrayList<Message> tempMassage;

    public UpdateJFrame(ArrayList<Message> allMessage, int isChoose2){
        index = isChoose2 -1;
        m = allMessage.get(index);
        tempMassage = allMessage;
        //1.初始化界面
        initJFrame();
        //2.初始化组件
        initView();

        //显示组件
        this.setVisible(true);

    }


    private void initView() {
        //1.标题
        JLabel everyDay = new JLabel("每日一记");
        everyDay.setBounds(220, 0, 70, 90);
        pane.add(everyDay);

        JLabel title = new JLabel("标题");
        title.setBounds(50,65,50,30);
        //JTextField  和JTextArea  两者都是输入框，后者输入和显示文本从左上角开始，还有自动换行

        titleField.setBounds(100,65,350,30);

        JLabel text = new JLabel("内容");
        text.setBounds(50,100,50,30);
        //设置内容
        titleField.setText(m.getTitle());
        textArea.setText(m.getText());

        //设置可换行
        textArea.setLineWrap(true);

        textArea.setBounds(100,100,350,300);

        //添加到界面中
        pane.add(title);
        pane.add(titleField);
        pane.add(text);
        pane.add(textArea);
        //添加到集合
        list.add(titleField);
        list.add(textArea);

        //添加两按钮

        updateButton.setBounds(120,410,100,30);
        cancelButton.setBounds(270,410,100,30);

        pane.add(updateButton);
        pane.add(cancelButton);

        //添加监听
        titleField.addKeyListener(this);
        textArea.addKeyListener(this);
        cancelButton.addKeyListener(this);

        updateButton.addActionListener(this);
        cancelButton.addActionListener(this);
    }

    private void initJFrame() {
        //1.设置大小
        this.setSize(500, 500);
        //2.设置标题
        this.setTitle("notepad修改");
        //3.设置关闭模式
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        //4.设置居中
        this.setLocationRelativeTo(null);
        //5.取消内部默认布局
        this.setLayout(null);
        //6.设置置顶
        this.setAlwaysOnTop(true);
        //7.设置背景颜色
        pane.setBackground(Color.LIGHT_GRAY);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object obj = e.getSource();
        if(obj == updateButton){
            //1.修改集合内容
            Message message = tempMassage.get(index);
            message.setTitle(titleField.getText());
            message.setText(textArea.getText());
            //2.序列化保存到本地
            CommentUtil.loadFile(tempMassage,"..\\notepad\\src\\com\\itheima\\log\\allLog.ser");
            CommentUtil.showJDialog("修改成功",this);
            //3.关闭当前界面并打开AppJFrame
            this.setVisible(false);
            try {
                new AppJFrame();
            } catch (IOException | ClassNotFoundException ex) {
                throw new RuntimeException(ex);
            }

        }
        else if(obj == cancelButton){
            this.setVisible(false);
            try {
                new AppJFrame();
            } catch (IOException | ClassNotFoundException ex) {
                throw new RuntimeException(ex);
            }
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        int index = getIndex(list,e.getSource());
        if (code == KeyEvent.VK_TAB) { // 使用常量更清晰，避免直接用9
            // 消费事件，阻止默认行为（如输入制表符或默认焦点切换）
            e.consume();
            index = index == 0 ? 1 : 0;
            list.get(index).requestFocusInWindow();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        Object obj = e.getSource();
        int index = getIndex(list,obj);

        JTextComponent component = list.get(index);
        if(code == 38){
            //按键盘 ↑ 时光标移至前面
            component.requestFocusInWindow();
            component.setCaretPosition(0);
        }
        else if(code == 40 ){
            //按键盘 ↓ 时光标移至后面
            component.requestFocusInWindow();
            component.setCaretPosition(component.getText().length());
        }
        else if(code == 27){
            //按esc时取消更改，返回
            this.setVisible(false);
            try {
                new AppJFrame();
            } catch (IOException | ClassNotFoundException ex) {
                throw new RuntimeException(ex);
            }
        }
    }

    /*
    * 作用：定位当前组件
    * 参数：装有两个输入框的集合
      返回值：索引
     */

    public int getIndex(ArrayList<JTextComponent> list, Object obj){
        return obj == list.get(0) ? 0 : 1;
    }
}
