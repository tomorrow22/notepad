package com.itheima.ui;

import com.itheima.domain.JLabelItem;
import com.itheima.domain.Message;
import com.itheima.util.CommentUtil;
import com.itheima.util.FileThread;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

//主界面的代码
public class AppJFrame extends JFrame implements ActionListener {

    //是否选择条目
    int isChoose2 = -1;
    //装有条目子条目的集合
    //作用：
    //1.记录所有添加的条目，后续方便管理
    //2.是下一条目位置的判断前提
    //all集合只添加JLabelItem对象中的allLabel,但allLabelItem装的是整个对象
    //二者做工不同
    ArrayList<JLabel> all = new ArrayList<>();
    ArrayList<JLabelItem> allLabelItem = new ArrayList<>();
    //装有所有信息对象
    ArrayList<Message> allMessage = new ArrayList<>();
    //记录多选的条目
    ArrayList<JLabelItem> allChooseItem = new ArrayList<>();
    //导出的关键值
    boolean isMore = true;
    //装有主界面用到的所有按钮
    JButton[] allJButton = new JButton[5];
    JButton update = new JButton("修改");
    JButton delete = new JButton("删除");
    JButton add = new JButton("添加");
    Container pane = this.getContentPane();
    //是否删除
    boolean isDelete = false;
    //提示的按钮
    JButton yes = new JButton("确认");
    JButton no = new JButton("取消");
    //导出选择按钮
    JButton choose = new JButton("选好啦！");
    JButton exit = new JButton("返回");
    //文件导出位置
    JMenuItem fileLocation = new JMenuItem("文件导出位置");
    //导入文件的按钮
    JButton fileYes = new JButton("确认");
    JButton fileNo = new JButton("取消");
    //导入
    JMenuItem importItem = new JMenuItem("导入");
    //导出文件的按钮
    JButton fileOutYes = new JButton("确认");
    JButton fileOutNo = new JButton("取消");
    //导出
    JMenuItem exportItem = new JMenuItem("导出");
    //地址输入框
    JTextField filePath = new JTextField();
    //地址展示框
    JTextField fileShow = new JTextField();

    //条目数量
    int size = 0;
    JDialog jd = new JDialog();
    //显示导入文件的
    JDialog jd2 = new JDialog();
    //显示导出文件的
    JDialog jd3 = new JDialog();
    //总条目
    int count = 0;
    //配置文件
    Properties pro = new Properties();
    //再次点击导出
    boolean isClickExport = false;
    //装有所有文件对象的集合
    ArrayList<File> files = new ArrayList<>();
    //装所有线程对象
    ArrayList<Thread> threads = new ArrayList<>();
    public AppJFrame() throws IOException, ClassNotFoundException {
        //初始化界面
        initJFrame();
        //初始化组件
        initView();
        //加载信息
        loadMessage();
        //显示界面
        this.setVisible(true);
    }


    private void initView() throws IOException {
        //1.标题
        JLabel everyDay = new JLabel("每日一记");
        everyDay.setBounds(220, 40, 70, 90);
        pane.add(everyDay);
        //导入/导出菜单
        JMenuBar action = new JMenuBar();

        //功能
        JMenu function = new JMenu("功能");
        JMenu settings = new JMenu("设置");

        //读取配置文件信息
        pro.load(new FileReader("..\\notepad\\src\\filepath.properties"));
        fileShow.setText(pro.getProperty("path"));

        //添加到整体界面
        function.add(importItem);
        function.add(exportItem);

        settings.add(fileLocation);

        action.add(function);
        action.add(settings);
        //设置菜单 this.getContentPane() 表示的是隐藏容器，添加菜单是给窗口添加，所以是this
        this.setJMenuBar(action);


        //设置按钮大小
        update.setBounds(200, 350, 75, 40);
        add.setBounds(100, 350, 75, 40);
        delete.setBounds(300, 350, 75, 40);
        choose.setBounds(150,350,100,40);
        exit.setBounds(300,350,100,40);
        //添加到数组中统一管理
        allJButton[0] = add;
        allJButton[1] = update;
        allJButton[2] = delete;
        allJButton[3] = choose;
        allJButton[4] = exit;
        //添加、修改和删除三个按钮跟 选择和返回两个按钮是不同时显示的
        displayJButton();
        //添加到界面
        pane.add(update);
        pane.add(add);
        pane.add(delete);
        pane.add(choose);
        pane.add(exit);

        //给按钮添加监听
        update.addActionListener(this);
        add.addActionListener(this);
        delete.addActionListener(this);
        choose.addActionListener(this);
        exit.addActionListener(this);

        importItem.addActionListener(this);
        exportItem.addActionListener(this);
        fileLocation.addActionListener(this);
    }
    //显示按钮
    private void displayJButton() {
        for (int i = 0; i < 5; i++) {
            if(i >= 3){
                allJButton[i].setVisible(!isMore);
            }else{
                allJButton[i].setVisible(isMore);
            }
        }
    }
    //加载信息
    public void loadMessage() throws IOException, ClassNotFoundException {
        //创建提示栏的对象
        JLabelItem item = new JLabelItem("编号", "标题", "正文", false,false);
        item.setAllLabelBounds(100, 100, 300, 30);
        //添加到总集合中
        all.add(item.getAllLabel());
        allLabelItem.add(item);

        pane.add(item.getAllLabel());

        //1.通过反序列化读取文件信息加载条目
        //目录不存在时创建
        File file = new File("..\\notepad\\src\\com\\itheima\\log");
        file.mkdirs();
        File f = new File(file, "allLog.ser");

        if ((!f.exists() || f.length() == 0)) {
            notEverythingMessage();
            return;
        }

        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));

        ArrayList<Message> o = (ArrayList<Message>) ois.readObject();
        //集合为空就返回了
        if (o.isEmpty()) {
            notEverythingMessage();
            return;
        }

        for (Message m : o) {
            //添加到总信息集合
            allMessage.add(m);
            size = allMessage.size();
            //创建条目的对象，将信息放入
            JLabelItem item2 = new JLabelItem(size + "", m.getTitle(), m.getText(), true,isMore);
            item2.setAllLabelBounds(100, 100 + (30 * all.size()), 300, 30);

            all.add(item2.getAllLabel());
            allLabelItem.add(item2);
            pane.add(item2.getAllLabel());
        }
    }

    //初始化界面
    private void initJFrame() {
        //1.设置大小
        this.setSize(500, 500);
        //2.设置标题
        this.setTitle("主界面");
        //3.设置关闭模式
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        //4.设置居中
        this.setLocationRelativeTo(null);
        //5.取消内部默认布局
        this.setLayout(null);
        //6.设置置顶
        this.setAlwaysOnTop(true);
        //7.设置背景颜色
        pane.setBackground(Color.LIGHT_GRAY);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        isChoose2 = getItem(all);
        if (source == update) {
            if (isChoose2 == -1) {
                CommentUtil.showJDialog("请先选择修改条目", this);
                return;
            }
            this.setVisible(false);
            //将信息对象传参到更新界面
            new UpdateJFrame(allMessage, isChoose2);
        } else if (source == delete) {
            if (isChoose2 == -1) {
                CommentUtil.showJDialog("请先选择删除条目", this);
                return;
            }
            //删除----------添加个提示框
            notEverythingMessage("是否删除该条记录？");
            if (!isDelete) {
                return;
            }
            //1.获取要删除的条目
            JLabel label = all.get(isChoose2);
            //记录要删除条目的Y值
            int y = (int) label.getLocation().getY();
            //记录当前删除的条目，也是下一条目编号的值
            int detectCount = isChoose2;
            //2.从集合中删除该条目
            all.remove(label);
            allMessage.remove(isChoose2 - 1);
            //3.从界面中删除该条目
            pane.remove(label);
            //4.将剩下的条目往上移
            for (int i = isChoose2 + 1; i < allLabelItem.size(); i++) {
                allLabelItem.get(i).setAllLabelBounds(100, y, 300, 30);
                allLabelItem.get(i).getCountLabel().setText(detectCount + "");
                //因为每条高30，所以+30
                detectCount++;
                y = y + 30;
            }
            //从集合中删除
            allLabelItem.remove(isChoose2);
            //5.刷新
            pane.repaint();

            if (allMessage.isEmpty()) {
                notEverythingMessage();
            }

            //删除完保存到本地文件
            CommentUtil.loadFile(allMessage, "..\\notepad\\src\\com\\itheima\\log\\allLog.ser");
        } else if (source == add) {
            //关闭当前界面
            this.setVisible(false);
            //打开添加界面
            new AddJFrame(allMessage);
        } else if (source == yes) {
            isDelete = true;
            //jd.setVisible(false);
            jd.dispose();
        } else if (source == no) {
            isDelete = false;
            //jd.setVisible(false);
            jd.dispose();
        } else if (source == importItem) {
            //导入
            if(isClickExport){
               CommentUtil.showJDialog("请先退出导出界面",this);
               return;
            }
            showPrompt("导入地址(能力有限，目前仅支持txt文件)","支持文件或文件夹",fileYes,fileNo,filePath,jd2);
        } else if (source == exportItem) {
            //导出
            if(isClickExport){
                exitSettings();
                return;
            }
            isClickExport = true;
            isMore = !isMore;
            //设置可多选
            for (int i = 1; i < allLabelItem.size(); i++) {
                allLabelItem.get(i).setNotMore(isMore);
            }
            //加载按钮
            displayJButton();

        } else if (source == fileYes) {
            //导入确认
            String text = filePath.getText();
            if(text.equals("")){
                return;
            }

            File f = new File(text);
            if (!f.exists()) {
                CommentUtil.showJDialog("路径错误或文件不存在", this);
                return;
            }
            //jd2.setVisible(false);
            jd2.dispose();
            //遍历获取
            try {
                //常规导入
                //importFile(f);

                //多线程导入
                //获取所有的txt文本
                getFile(f);
                //遍历进行导入
                threads.clear();
                //清空变量
                FileThread.zero();
                for (File file : files) {
                    Thread t = new Thread(new FileThread(file,null,null),"导入-"+ file);
                    threads.add(t);
                    t.start();
                }
                //插入
                for (Thread t : threads) {
                    t.join();
                }
                //导入条数
                count = FileThread.getSize();
                //添加到所有信息集合中
                ArrayList<Message> addList = FileThread.getAddList();
                allMessage.addAll(addList);
                //添加完后保存
                CommentUtil.loadFile(allMessage, "..\\notepad\\src\\com\\itheima\\log\\allLog.ser");
                CommentUtil.showJDialog("本次共导入" + count + "条",this);
                count = 0;
                //重新加载信息
                //删除组件
                for (JLabel label : all) {
                    pane.remove(label);
                }
                //清空集合
                allMessage.clear();
                all.clear();
                allLabelItem.clear();
                files.clear();
                //重新加载信息
                loadMessage();
                //刷新
                pane.repaint();
                filePath.setText("");
            } catch (IOException | ClassNotFoundException | InterruptedException ex) {
                throw new RuntimeException(ex);
            }
        } else if (source == fileNo) {
            //导入取消
            filePath.setText("");
            //jd2.setVisible(false);
            jd2.dispose();
        }
        else if(source == fileOutNo){
            //jd3.setVisible(false);
            jd3.dispose();
        }
        else if(source == fileOutYes){
            //导出
            pro.put("path",fileShow.getText());
            try {
                //更新导出地址
                pro.store(new FileWriter("..\\notepad\\src\\filepath.properties"),"properties");
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
            //jd3.setVisible(false);
            jd3.dispose();
        }
        else if(source == choose){
            String pathText = fileShow.getText();
            if(pathText.equals("")){
                CommentUtil.showJDialog("请先设置导出文件位置",this);
                exitSettings();
                return;
            }
            File file = new File(pathText);
            if(!file.exists()){
                CommentUtil.showJDialog("路径不存在，请检查",this);
                exitSettings();
                return;
            }
            //选择
            allChooseItem.clear();
            getAllItem(all);

            String path;
            //当路径是文件夹时，文件导出的位置就是 当前路径+日志导出.zip
            //当路径是文件时，文件导出的位置就是   当前路径的父级路径 + 日志导出.zip
            if(file.isDirectory()){
                path = file.toString();
            }else{
                path = file.getParent();
            }

            //创建压缩流进行压缩写出
            try {
                //创建文件位置
                File resultPath = new File(path, new Date().getTime() +".zip");
                //创建压缩包
                resultPath.createNewFile();
                //常规压缩
                /*//1.创建压缩流的对象
                ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(resultPath));
                for (JLabelItem item : allChooseItem) {
                    //2.添加ZipEntry对象
                    //参数：就是在压缩包中的文件名
                    ZipEntry entry = new ZipEntry(item.getTitleLabel().getText()+".txt");
                    zos.putNextEntry(entry);
                    //写入数据
                    zos.write(item.getTextLabel().getText().getBytes());
                    //写完关闭当前ZipEntry对象
                    zos.closeEntry();
                }
                //整个写完关流
                zos.close();*/

                //多线程
                //1.创建唯一的流
                ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(resultPath));
                //装入线程对象
                threads.clear();
                //遍历条目对象进行压缩
                for (JLabelItem item : allChooseItem) {
                    Thread t = new Thread(new FileThread(null,item,zos),"导出-"+item.getCountLabel().getText());
                    threads.add(t);
                    t.start();
                }
                //插入
                for (Thread t : threads) {
                    t.join();
                }

                //关流
                zos.close();
            } catch (IOException | InterruptedException ex) {
                throw new RuntimeException(ex);
            }
            //提示
            CommentUtil.showJDialog("导出成功",this);
            exitSettings();
        }
        else if(source == exit){
            //返回
            exitSettings();
        }
        else if(source == fileLocation){
            String path = pro.getProperty("path");
            fileShow.setText(path);
            showPrompt("当前导出地址为：","导出地址",fileOutYes,fileOutNo,fileShow,jd3);
        }

    }
    //获取所有txt文本对象
    public  void getFile(File file) {
        if (file.isFile() && file.getName().endsWith("txt")) {
            files.add(file);
        } else if (file.isDirectory()) {
            File[] files = file.listFiles();
            if (files == null) {
                return;
            }
            for (File file1 : files) {
                getFile(file1);
            }
        }
    }

    /*
    * 作用：取消条目可多选并加载一些按钮和隐藏一下按钮
    * */
    private void exitSettings() {
        //重新设置是否可多选
        isMore = !isMore;
        //将颜色变回未点击状态
        //设置Click为未点击状态
        for (int i = 1; i < allLabelItem.size(); i++) {
            JLabelItem item = allLabelItem.get(i);
            item.getCountLabel().setBackground(Color.LIGHT_GRAY);
            item.getTitleLabel().setBackground(Color.LIGHT_GRAY);
            item.getTextLabel().setBackground(Color.LIGHT_GRAY);
            item.getAllLabel().setBackground(Color.LIGHT_GRAY);
            item.setNotMore(isMore);
            item.setClick(false);
        }
        //加载按钮
        displayJButton();
        //刷新
        pane.repaint();
        isClickExport = false;
    }

    //导入文件
    //参数：文件或文件夹
    private void importFile(File file) throws IOException {
        if (file.isFile() && file.getName().endsWith("txt")) {
            //定义标题和内容
            String title = null;
            StringBuilder sb = new StringBuilder();
            //1.文件名
            title = file.getName().split("\\.")[0];
            //读取内容
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append("\r\n");
            }
            br.close();
            //个数++
            count++;
            //添加到界面中
            Message e = new Message("1", title, sb.toString());
            allMessage.add(e);
        }else{
            //2.文件夹
            File[] files = file.listFiles();
            if(files == null){
                return;
            }
            for (File file1 : files) {
                importFile(file1);
            }
        }
    }

    /*
     * 作用：获取当前被点击条目的索引
     * 参数：装有子条目的集合
     * */
    public int getItem(ArrayList<JLabel> list) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getBackground() != Color.LIGHT_GRAY) {
                return i;
            }
        }
        return -1;
    }

    //获取所有选中的条目
    public void getAllItem(ArrayList<JLabel> list) {
        for (int i = 1; i < list.size(); i++) {
            JLabel jLabel = list.get(i);
            if (jLabel.getBackground() != Color.LIGHT_GRAY) {
                allChooseItem.add(allLabelItem.get(i));
            }
        }
    }

    public void notEverythingMessage(String str) {
        //设置大小
        jd.setSize(200, 200);
        //设置置顶
        jd.setAlwaysOnTop(true);
        //设置关闭模式
        jd.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        //设置居中
        jd.setLocationRelativeTo(this);
        //设置标题
        jd.setTitle("提示");
        //弹窗不关闭则无法进行下面操作
        jd.setModal(true);
        //取消内部默认布局
        jd.setLayout(null);
        //创建JLabel对象
        JLabel message = new JLabel(str);
        //设置位置大小
        message.setBounds(0, 30, 300, 60);
        //添加到JDialog中
        jd.getContentPane().add(message);


        yes.setBounds(15, 110, 60, 30);
        no.setBounds(110, 110, 60, 30);


        yes.addActionListener(this);
        no.addActionListener(this);

        jd.getContentPane().add(yes);
        jd.getContentPane().add(no);


        //显示弹窗
        jd.setVisible(true);
    }

    /*
    * 作用：没有信息时展示
    * */
    public void notEverythingMessage() {
        JLabel notEverything = new JLabel("当前无任何信息");
        notEverything.setBounds(200, 190, 300, 60);
        pane.add(notEverything);
    }

    /*
    * 作用：展示一个弹框
    * 参数一：要显示的提示
    * 参数二：弹框的标题
    * 参数三：该弹框的确认按钮
    * 参数四：该弹框的取消按钮
    * 参数五：该弹框的输入框
    * */
    public void showPrompt(String str,String title,JButton jYes,JButton jNo,JTextField showFile,JDialog jdi) {
        //设置大小
        jdi.setSize(250, 200);
        //设置置顶
        jdi.setAlwaysOnTop(true);
        //设置关闭模式
        jdi.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        //设置居中
        jdi.setLocationRelativeTo(this);
        //设置标题
        jdi.setTitle(title);
        //弹窗不关闭则无法进行下面操作
        jdi.setModal(true);
        //取消内部默认布局
        jdi.setLayout(null);
        //创建JLabel对象
        JLabel message = new JLabel(str);
        //设置位置大小
        message.setBounds(0, 0, 300, 60);

        //地址输入框
        showFile.setBounds(0, 50, 200, 20);
        //添加到JDialog中
        jdi.getContentPane().add(message);
        jdi.getContentPane().add(showFile);


        jYes.setBounds(15, 110, 60, 30);
        jNo.setBounds(110, 110, 60, 30);


        jYes.addActionListener(this);
        jNo.addActionListener(this);

        jdi.getContentPane().add(jYes);
        jdi.getContentPane().add(jNo);

        //显示弹窗
        jdi.setVisible(true);
    }

}
