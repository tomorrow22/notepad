package com.itheima.test;

import com.itheima.domain.JLabelItem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
public class JLabel_1 extends JFrame implements ActionListener {

    //是否选择条目
    int isChoose2 = -1;
    //装有条目子条目的集合
    //作用：
    //1.记录所有添加的条目，后续方便管理
    //2.是下一条目位置的判断前提
    ArrayList<JLabel> all = new ArrayList<>();
    JButton look = new JButton("查看");
    Container pane = this.getContentPane();
    public JLabel_1() {

        initJFrame();

        //initView();


        this.setVisible(true);
    }

    /*private void initView() {
        //1.标题
        JLabel everyDay = new JLabel("每日一记");
        everyDay.setBounds(220, 40, 70, 90);
        //创建提示栏的对象
        JLabelItem item = new JLabelItem("个数", "标题", "正文",false);
        item.setAllLabelBounds(100,100,300,30);
        //添加到总集合中
        all.add(item.getAllLabel());

        pane.add(item.getAllLabel());

        pane.add(everyDay);

        for (int i = 0; i < 3; i++) {

            JLabelItem item2 = new JLabelItem(all.size() + "", "快乐的一天", "今天度过了不快乐的一天",true);

            item2.setAllLabelBounds(100,100 + (30 * all.size()),300,30);
            all.add(item2.getAllLabel());

            pane.add(item2.getAllLabel());
        }


        look.setBounds(100,250,75,40);
        look.addActionListener(this);
        pane.add(look);



    }*/

    private void initJFrame() {
        this.setSize(500, 500);
        this.setTitle("测试");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setLayout(null);
        this.setAlwaysOnTop(true);

        this.getContentPane().setBackground(Color.LIGHT_GRAY);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if(source == look){
            isChoose2 = getItem(all);
            System.out.println(isChoose2);
        }
    }

    /*
    * 作用：获取当前被点击条目的索引
    * 参数：装有子条目的集合
    * */
    public int getItem(ArrayList<JLabel> list){
        for (int i = 0; i < list.size(); i++) {
            if(list.get(i).getBackground() != Color.LIGHT_GRAY){

                return i;
            }
        }
        return -1;
    }
}
