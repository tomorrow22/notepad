package com.itheima.test;

import com.itheima.domain.JLabelItem;
import com.itheima.domain.Message;
import com.itheima.util.FileThread;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.zip.ZipOutputStream;

public class ThreadTest {
    static ArrayList<File> list = new ArrayList<>();
    public static void main(String[] args) throws InterruptedException, IOException {
        //importFileTest();

        ArrayList<JLabelItem> items = new ArrayList<>();
        items.add(new JLabelItem("1","title1","hahah1",false,false));
        items.add(new JLabelItem("2","title2","hahah2",false,false));
        items.add(new JLabelItem("3","title3","hahah3",false,false));

        ArrayList<Thread> zipAllThread = new ArrayList<>();
        String file = "C:\\Users\\MR\\Desktop\\a.zip";
        ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(file));
        for (JLabelItem item : items) {
            Thread t = new Thread(new FileThread(new File(file),item,zos),"导出-" + file);
            zipAllThread.add(t);
            t.start();
        }

        for (Thread thread : zipAllThread) {
            thread.join();
        }

        zos.close();

    }

    private static void importFileTest() throws InterruptedException {
        //多线程导入测试
        File file = new File("E:\\ddd\\csb.txt");
        getFile(file);
        System.out.println(list);
        ArrayList<Thread> threads = new ArrayList<>();

        for (File f : list) {
            Thread ft = new Thread(new FileThread(f,null,null),"导入-"+f);
            threads.add(ft);
            ft.start();
        }

        for (Thread thread : threads) {
            thread.join();
        }

        int size = FileThread.getSize();
        System.out.println("本次共导入"+size+"条");
    }

    public static void getFile(File file) {
        if (file.isFile() && file.getName().endsWith(".txt")) {
            list.add(file);
        } else if (file.isDirectory()) {
            File[] files = file.listFiles();
            if (files == null) {
                return;
            }
            for (File file1 : files) {
                getFile(file1);
            }
        }
    }
}
