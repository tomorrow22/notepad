package com.itheima.test;

public class JLabelTest {
    public static void main(String[] args) {
        new JLabel_1();
        //new ItemLabel();
    }
}
