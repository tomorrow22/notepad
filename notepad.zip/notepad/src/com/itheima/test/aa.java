package com.itheima.test;

import java.io.File;
import java.io.IOException;
import java.util.Date;

public class aa {
    public static void main(String[] args) throws IOException {

        File resultPath = new File("C:\\Users\\MR\\Desktop",(new Date().getTime()) +".zip");
        System.out.println(resultPath);
        //创建压缩包
        resultPath.createNewFile();
    }
}
