package com.itheima.test;

import com.itheima.util.CommentUtil;

import javax.swing.*;

public class JDialogTest {
    public static void main(String[] args) {
        JFrame j = new JFrame();
        j.setSize(500,500);



        j.setVisible(true);

        //CommentUtil.showJDialog("提示",j);
    }
}
