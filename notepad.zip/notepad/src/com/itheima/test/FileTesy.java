package com.itheima.test;

import com.itheima.domain.Message;

import java.io.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class FileTesy {
    public static int count;
    public static void main(String[] args) throws IOException {
        File resultPath = new File("C:\\Users\\MR\\Desktop\\日志导出.zip");
        //System.out.println(resultPath);

        if(!resultPath.exists()){
            resultPath.createNewFile();
        }
        if(resultPath.isDirectory()){
            //文件夹
            System.out.println("this is Directory:"+resultPath.toString());
        }else{
            //文件
            System.out.println("this is File:"+resultPath.getParent());
        }

        zipFile(resultPath);

    }

    public static void zipFile(File file) throws IOException {
        //1.创建压缩包
        ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(file));
        //2.在压缩包中创建文件
        //创建zipEntry对象
        ZipEntry entry = new ZipEntry("a.txt");
        //添加
        zos.putNextEntry(entry);

        String str = "其实也不算是bug。因为不影响运行\n" +
                "原因：在添加时编号是固定的。因此比如有3条记录时，删除前面一条会只有两条记录，但是编号还是 1 和3 不会自己变成 1和 2\n" +
                "\n" +
                "解决：\n" +
                "方案1.将编号定为动态，在每次进入主界面（APPJFrame）时按照条目进行编号自增，删除时编号自减。依次来实现编号动态改变\n" +
                "\n" +
                "可行指数四颗星：虽然这样的话封装的信息集合就用不到编号这个变量了，但是相比方案2来说性能更好\n" +
                "\n" +
                "方案2：在每次删除时修改删除后面的所有信息编号（因为信息是封装的，所以要遍历集合进行修改）\n" +
                "\n" +
                "可行指度两颗星：要遍历修改，若条目多则影响性能";

        //3.写入数据
        zos.write(str.getBytes());
        zos.closeEntry();

        zos.close();


    }

    private static void method(File f) {
        if(f.isFile()){
            System.out.println(f);
        }else{
            File[] files = f.listFiles();
            if(files == null){
                return;
            }
            for (File file : files) {
                method(file);
            }
        }
    }

    private static void importFile(File file) throws IOException {
        if (file.isFile()) {
            //定义标题和内容
            String title = null;
            StringBuilder sb = new StringBuilder();
            //1.文件
            title = file.getName().split("\\.")[0];
            //读取内容
            System.out.println(file);
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            br.close();
            count++;
            System.out.println(title);
            System.out.println(sb.toString());
        }else{
            //2.文件夹
            File[] files = file.listFiles();
            if(files == null){
                return;
            }
            for (File file1 : files) {
                importFile(file1);
            }
        }
    }
}
