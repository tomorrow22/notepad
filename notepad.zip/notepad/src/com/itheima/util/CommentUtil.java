package com.itheima.util;
import javax.swing.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

/*
 * 提供组件操作的一些工具类
 * */
public class CommentUtil {
    private CommentUtil() {
    }

    /*
     * 作用：提示框
     * 参数一：提示的内容
     * 参数二：界面（弹窗相对于父级界面居中）
     * */
    public static void showJDialog(String str, JFrame j) {
        JDialog jd = new JDialog();
        //设置大小
        jd.setSize(200, 200);
        //设置置顶
        jd.setAlwaysOnTop(true);
        //设置关闭模式
        jd.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        //设置居中
        jd.setLocationRelativeTo(j);
        //设置标题
        jd.setTitle("提示");
        //弹窗不关闭则无法进行下面操作
        jd.setModal(true);
        //取消内部默认布局
        jd.setLayout(null);
        //创建JLabel对象
        JLabel message = new JLabel(str);
        //设置位置大小
        message.setBounds(0, 30, 300, 60);
        //添加到JDialog中
        jd.getContentPane().add(message);

        //添加两个按钮
        JButton yes = new JButton("确认");
        JButton no = new JButton("取消");
        yes.setBounds(15, 110, 60, 30);
        no.setBounds(110, 110, 60, 30);


        yes.addActionListener(e -> jd.dispose());

        no.addActionListener(e -> jd.dispose());

        jd.getContentPane().add(yes);
        jd.getContentPane().add(no);

        //显示弹窗
        jd.setVisible(true);
    }
    /*
    * 作用：通过序列化流保存文件
    * 参数一：要保存的集合
    * 参数二：保存文件的位置
    * */
    public static <E> void loadFile(ArrayList<E> list, String file){
        //2.序列化保存到本地
        File f = new File(file);
        //当文件只读或者不可写入时 更改成可写入
        if(f.canRead() || !f.canWrite()){
            f.setWritable(true);
        }

        try {
            //创建序列化对象
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
            //写入
            oos.writeObject(list);
            //关流
            oos.close();
            //设置文件只读
            f.setReadOnly();

        } catch (IOException  ex) {
            throw new RuntimeException(ex);
        }
    }
}
