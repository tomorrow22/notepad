package com.itheima.util;

import com.itheima.domain.JLabelItem;
import com.itheima.domain.Message;

import java.io.*;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class FileThread implements Runnable {

    private static int size = 0;
    private static ArrayList<Message> addList = new ArrayList<>();
    private  JLabelItem item;
    private File file;
    private ZipOutputStream zos;

    public FileThread(File file,JLabelItem item,ZipOutputStream zos) {
        this.file = file;
        this.item = item;
        this.zos = zos;
    }

    @Override
    public void run() {
        //处理单个文件的导入，然后多线程启动
        if (Thread.currentThread().getName().startsWith("导入")) {
            try {
                importFile(file);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        } else {
            try {
                zipFile();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    //导入
    private void importFile(File file) throws IOException {
        if (file.isFile() && file.getName().endsWith("txt")) {
            //定义标题和内容
            String title = null;
            //StringBuilder sb = new StringBuilder();
            StringBuffer sb = new StringBuffer();
            //1.文件名
            title = file.getName().split("\\.")[0];
            //读取内容
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append("\r\n");
            }
            br.close();
            //添加到界面中
            Message e = new Message("1", title, sb.toString());
            synchronized (FileThread.class) {
                //个数++
                size++;
                addList.add(e);
            }
        }
    }

    //导出
    private void zipFile() throws IOException {
        synchronized (zos){
            //1.创建压缩流的对象
            //2.添加ZipEntry对象
            //参数：就是在压缩包中的文件名
            ZipEntry entry = new ZipEntry(item.getTitleLabel().getText() + ".txt");
            zos.putNextEntry(entry);
            //写入数据
            zos.write(item.getTextLabel().getText().getBytes());
            //写完关闭当前ZipEntry对象
            zos.closeEntry();
        }
    }

    public static int getSize() {
        return size;
    }

    public static ArrayList<Message> getAddList() {
        return addList;
    }

    public static void zero(){
        size = 0;
        addList.clear();
    }
}
