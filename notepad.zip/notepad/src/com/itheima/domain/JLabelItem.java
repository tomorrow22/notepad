package com.itheima.domain;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

public class JLabelItem extends JLabel implements MouseListener {
    //封装JLabel的类

    //定义颜色
    private Color LIGHT_GRAY = Color.LIGHT_GRAY;
    private Color cyan = Color.cyan;
    private Color white = Color.white;
    private Color BLACK = Color.BLACK;
    //定义静态数组
    //作用：当条目被点击之后添加到集合中，再次点击另一条目时前一条目变回未点击状态
    /*
    * 不加静态会表示可以选中多条，我不想这样；
    * */
    public static ArrayList<JLabelItem> list = new ArrayList<>();
    //是否已经点击
    private boolean isClick = false;
    //管理整个条目的JLabel
    private JLabel allLabel;

    //序号JLabel
    private JLabel countLabel;
    //标题JLabel
    private JLabel titleLabel;
    //正文JLabel
    private JLabel textLabel;
    boolean notMore;
    /*
    * 构造方法：用于构造条目的对象
    * 参数一：条目的个数
    * 参数二：条目的标题
    * 参数三：条目的正文
    * 参数四：是否添加鼠标监听（因为第一条是提示，所以不需要）
    * 参数五：是否可多选
    * */
    public JLabelItem(String count, String title, String text,boolean isAddMouseListener,boolean notMore) {
        //1.给JLabel 设置文本
        countLabel = new JLabel(count);
        titleLabel = new JLabel(title);
        textLabel = new JLabel(text);
        allLabel = new JLabel();
        this.notMore = notMore;
        //设置字体居中
        if(!isAddMouseListener){
            countLabel.setHorizontalAlignment(SwingConstants.CENTER);
            countLabel.setVerticalAlignment(SwingConstants.CENTER);
            titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
            titleLabel.setVerticalAlignment(SwingConstants.CENTER);
            textLabel.setHorizontalAlignment(SwingConstants.CENTER);
            textLabel.setVerticalAlignment(SwingConstants.CENTER);
        }

        //2.设置大小
        countLabel.setBounds(0, 0, 100, 30);
        titleLabel.setBounds(100, 0, 100, 30);
        textLabel.setBounds(200, 0, 100, 30);

        //3.设置背景颜色
        countLabel.setOpaque(true);
        titleLabel.setOpaque(true);
        textLabel.setOpaque(true);
        allLabel.setOpaque(true);

        countLabel.setBackground(LIGHT_GRAY);
        titleLabel.setBackground(LIGHT_GRAY);
        textLabel.setBackground(LIGHT_GRAY);
        allLabel.setBackground(LIGHT_GRAY);

        //将三个小组件添加到整个大组件中
        allLabel.add(countLabel);
        allLabel.add(titleLabel);
        allLabel.add(textLabel);

        //4.添加边框
        countLabel.setBorder(BorderFactory.createLineBorder(BLACK,1));
        titleLabel.setBorder(BorderFactory.createLineBorder(BLACK,1));
        textLabel.setBorder(BorderFactory.createLineBorder(BLACK,1));
        allLabel.setBorder(BorderFactory.createLineBorder(BLACK, 1));

        //5.添加监听
        if(isAddMouseListener){
            countLabel.addMouseListener(this);
            titleLabel.addMouseListener(this);
            textLabel.addMouseListener(this);
            allLabel.addMouseListener(this);
        }

        //6.显示
        countLabel.setVisible(true);
        titleLabel.setVisible(true);
        textLabel.setVisible(true);
        allLabel.setVisible(true);

    }


    public JLabel getAllLabel() {
        return allLabel;
    }
    public JLabel getCountLabel(){
        return countLabel;
    }

    public boolean getIsClick(){
        return isClick;
    }

    public static ArrayList<JLabelItem> getList() {
        return list;
    }

    public static void setList(ArrayList<JLabelItem> list) {
        JLabelItem.list = list;
    }

    public boolean isClick() {
        return isClick;
    }

    public void setClick(boolean click) {
        isClick = click;
    }

    public void setAllLabel(JLabel allLabel) {
        this.allLabel = allLabel;
    }

    public void setCountLabel(JLabel countLabel) {
        this.countLabel = countLabel;
    }

    public JLabel getTitleLabel() {
        return titleLabel;
    }

    public void setTitleLabel(JLabel titleLabel) {
        this.titleLabel = titleLabel;
    }

    public JLabel getTextLabel() {
        return textLabel;
    }

    public void setTextLabel(JLabel textLabel) {
        this.textLabel = textLabel;
    }

    public void setAllLabelBounds(int x, int y, int width, int height){
        allLabel.setBounds(x,y,width,height);
    }

    public boolean isNotMore() {
        return notMore;
    }

    public void setNotMore(boolean notMore) {
        this.notMore = notMore;
    }

    //单击
    @Override
    public void mouseClicked(MouseEvent e) {
        //当该类被点击时改变isClick的状态
        isClick = !isClick;
        //更新当前条目的背景色
        allLabel.setBackground(isClick ? cyan : LIGHT_GRAY);
        textLabel.setBackground(allLabel.getBackground());
        countLabel.setBackground(allLabel.getBackground());
        titleLabel.setBackground(allLabel.getBackground());

        if(notMore){
            //当notMore为true时意味着不可多选
            if(isClick){
                //该条目被点击了
                if(list.size() < 1){
                    //集合长度为0
                    list.add(this);
                }else {
                    //判断当前点击条目是否已经存在
                    JLabelItem item1 = list.get(0);
                    if(item1 == this){
                        return;
                    }
                    //集合长度不为0
                    //1.添加当前类到静态集合
                    list.add(this);
                    //删除前一条
                    JLabelItem item = list.remove(0);
                    //重置前一条目的状态
                    //该分支做的事是：当点击条目>= 2时，将上一条点击的条目重置
                    //              也就是说只能选择一个条目的意思
                    item.setClick(false);
                    JLabel label = item.getAllLabel();
                    label.setBackground(LIGHT_GRAY);
                    item.getTextLabel().setBackground(label.getBackground());
                    item.getCountLabel().setBackground(label.getBackground());
                    item.getTitleLabel().setBackground(label.getBackground());
                }
            }
        }
    }

    //按住不松
    @Override
    public void mousePressed(MouseEvent e) {

    }

    //松开
    @Override
    public void mouseReleased(MouseEvent e) {

    }

    //鼠标划入
    @Override
    public void mouseEntered(MouseEvent e) {
        textLabel.setBackground(white);
        countLabel.setBackground(white);
        titleLabel.setBackground(white);
    }

    //鼠标划出
    @Override
    public void mouseExited(MouseEvent e) {
        if(isClick){
            textLabel.setBackground(allLabel.getBackground());
            countLabel.setBackground(allLabel.getBackground());
            titleLabel.setBackground(allLabel.getBackground());
        }else{
            textLabel.setBackground(LIGHT_GRAY);
            countLabel.setBackground(LIGHT_GRAY);
            titleLabel.setBackground(LIGHT_GRAY);
        }

    }
}
